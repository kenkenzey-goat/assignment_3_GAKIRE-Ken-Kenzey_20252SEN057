**Name:** GAKIRE Ken Kenzey

**ID:** 20252SEN057

**Course:** Database PL/SQL



**Assignment:**

**Sections:**

1. Overview
2. How to run it
3. Assumptions 	
4. Results
5. Notes





1. **OVERVIEW**

The repository contains my work for assignment III in DB PL/SQL. It was built and tested using Oracle 21c.

It had 3 parts:

\- Part A (GOTO): Four PL/SQL programs that practice GOTO statements and labels. They include a number classifier (A1), a salary review (A2),

&#x20; an illegal GOTO with its fix (A3), and a rewrite of A2 without GOTO (A4).

\- Part B (Functions): Stored functions that calculate annual salary (B1), years of service (B2), tax (B3), and department name (B4), with exception

&#x20; handling. B5 shows these functions used inside SQL SELECT queries.

\- Part C (Combined task): A payroll validator function (C1) that uses the earlier functions to check whether an employee record is valid, and a

&#x20; short written reflection (C2) on what I learned.





**2. How to run it**

I read the questions from the assignment and put them in Oracle 21c and the SQL developer after creating create\_tables.sql then I run the codes there.





**3. Assumptions**

We didn't have tables in the work so I created them assuming the structure and called them employees and department.

We didn't have the data in the assignment so I decided to assume them after creating the tables to be able to have the data to manipulate through the GOT statements and the other questions.

Then I assumed the tax percentage.
| Monthly salary band | Tax rate |

|---------------------|----------|

| 0 to 60,000         |   0%     |

| 60,001 to 100,000   |   10%    |

| 100,001 to 200,000  |    20%   |

| Above 200,000       |   30%    |

|---------------------|----------|



**4. Results**

A1\_number\_classifier.sql-> A1\_result\_screenshot

GOTO jumps to the right label, so the number 7 is classified as positive and odd and the program ends at the shared `done` label.



A2\_salary\_review.sql-> A2\_result\_screenshot

Each employee is sent by GOTO to the correct salary band (invalid, low, mid, or high) and prints the matching raise message.



A3\_illegal\_goto.sql-> A3\_result\_screenshot

Jumping into an IF block fails with PLS-00375, and moving the label to the same block level as the GOTO fixes the error.



A4\_rewrite\_no\_goto.sql-> A4\_result\_screenshot

The CASE version gives exactly the same output as A2 but is shorter and easier to read and maintain.



B1\_fn\_annual\_salary.sql-> B1\_result\_screenshot



B2\_fn\_years\_of\_service.sql-> B2\_result\_screenshot



B3\_fn\_calculate\_tax.sql->B3\_result\_screenshot



B4\_fn\_dept\_name.sql->B4\_result\_screenshot



C1\_fn\_validate\_payroll.sql->C1\_result\_screenshot

The validator returns VALID for employees 101 to 105 and INVALID with a clear reason for the bad test rows (106, 107) and the missing employee 999.



B5\_functions\_in\_sleect.sql-> B5\_result\_screenshot

The functions work like built-in functions inside SELECT, WHERE, and ORDER BY, returning department name, annual salary, years of service, and tax for each valid employee.



test\_functions.sql-> test\_functions\_result\_screenshot



test\_validate\_payroll.sql-> test\_validate\_payroll\_result\_screenshot





**5. Notes**

I used an AI assistant (Claude) while working on this assignment. I used it to:

* explain the assignment and how GOTO works
* draft the sample code for me to edit
* helped me understand errors

I ran every script in Oracle 21c myself, checked the outputs and took the screenshots. I understand the code I submitted and can explain it.



